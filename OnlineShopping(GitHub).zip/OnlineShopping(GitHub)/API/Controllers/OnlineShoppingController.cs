﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShoppingBusinessLayerLib;// for Online shopping Business class

using OnlineShoppingEntitiesLib;// for Online shopping entity class

using OnlineShoppingExceptionLib;// for Online shopping data exception class


namespace OnlineShoppingSite.Controllers
{
    /// <summary>
    ///  This class extends the methods defined in business layer
    /// </summary>
    public class OnlineShoppingController : ApiController
    {
        /// <summary>
        /// This method will give all the names of the category
        /// </summary>
        /// <returns>returns all the categories</returns> 
        public HttpResponseMessage Get()
        {
            //If the items are added to the cart, it will return with httpstatus of OK and message of record found
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "Record found");
            // try block incase if code throws an exception
            try
            {
                //creates object  for onlineShopping Business layer class
                OnlineShoppingBusiness bll = new OnlineShoppingBusiness();
                //Retrives all the categories and stores in a variable
                var lstprd = bll.GetAllCategories();
                //returns list of categories 
                errRes = Request.CreateResponse<List<Category>>(HttpStatusCode.OK, lstprd);
            }
            //The exceptions will be handlesd here
            catch (Exception ex)
            {
                //If the items are not added to the cart, it will return  httpstatus of bad request and message of record not found
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "record not found");
            }
            //return the message
            return errRes;
        }
        /// <summary>
        /// This method will display the products based on the name given by user 
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products with the searched product</returns>
        [Route("api/OnlineShopping/GetProductsByProductName/{name}")]
        public HttpResponseMessage GetProductsByProductName(string name)
        {
                //If the items are added to the cart, it will return with httpstatus of OK and message of item found
                HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "item found");
                // try block incase if code throws an exception
                try
                {
                    //creates object  for onlineShopping Business layer class
                    OnlineShoppingBusiness bll = new OnlineShoppingBusiness();
                    //Retrives all the Products from the database and stores in the variable
                    var lstprd = bll.GetProductsByProductName(name);
                    //returns list of Products 
                    errRes = Request.CreateResponse<List<Product>>(lstprd);
                }
                //The exceptions will be handlesd here
                catch (Exception ex)
                {
                    //If the items are not added to the cart, it will return  httpstatus of bad request and message of item not found
                    errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "item not found");
                }
                //return the message
                return errRes;
        }
        /// <summary>
        /// This method will display the products present in category when clicked on category name
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products list present in the selected category</returns>
        [Route("api/OnlineShopping/GetProductsByCategoryName/{name}")]
        public HttpResponseMessage GetProductsByCategoryName(string name)
        {
            //If the items are added to the cart, it will return with httpstatus of OK and message of item found
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "item found");
            // try block incase if code throws an exception
            try
            {
                //creates object  for onlineShopping Business layer class
                OnlineShoppingBusiness bll = new OnlineShoppingBusiness();
                //Retrives all the products according to category name and stores in the variable
                var lstpdt = bll.GetProductsByCategoryName(name);
                //returns list of Products 
                errRes = Request.CreateResponse<List<Product>>(lstpdt);
            }
            //The exceptions will be handlesd here
            catch (Exception ex)
            {
                //If the items are not added to the cart, it will return  httpstatus of bad request and message of item not found
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "item not found");
            }
            //return the message
            return errRes;
        }
        /// <summary>
        /// This method will give full details of the product based on the product ID when clicked on the image
        /// </summary>
        /// <param name="id"></param>
        /// <returns>returns single product based on ID</returns>
        [Route("api/OnlineShopping/GetProductById/{id}")]
        public HttpResponseMessage GetProductById(int id)
        {
            //If the items are added to the cart, it will return with httpstatus of OK and message of item found
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "item found");
            // try block incase if code throws an exception
            try
            {
                //creates object  for onlineShopping Business layer class
                OnlineShoppingBusiness bll = new OnlineShoppingBusiness();
                //Retrives all the product details by ID and stores in the variable
                var prd = bll.GetProductById(id);
                //returns list of Product details
                errRes = Request.CreateResponse<Product>(prd);
            }
            //The exceptions will be handlesd here
            catch (Exception ex)
            {
                //If the items are not added to the cart, it will return  httpstatus of bad request and message of item not found
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "item not found");
            }
            //return the message
            return errRes;
        }
        /// <summary>
        /// This method will add the products to the cart when clicked on add to cart button 
        /// and returns to home page 
        /// </summary>
        /// <param name="lst"></param>
        public HttpResponseMessage Post([FromBody] List<CartProducts> lst)
        {
            //If the items are added to the cart, it will return with httpstatus of OK and message of record inserted
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "Record inserted");
            // try block incase if code throws an exception
            try
            {
                //creates object  for onlineShopping Business layer class
                OnlineShoppingBusiness bll = new OnlineShoppingBusiness();
                //adds all the cart products
                bll.AddToCart(lst);
            }
            //The exceptions will be handlesd here
            catch (Exception ex)
            {
                //If the items are not added to the cart, it will return  httpstatus of bad request and message of item could not be added
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "item could not be added");
            }
            //return the message
            return errRes;
        }
        /// <summary>
        /// This method get all the cart products
        /// </summary>
        /// <returns>returns cart products</returns>
        [Route("api/OnlineShopping/GetFromCart")]
        public HttpResponseMessage  GetFromCart()
        {
            //If the items are added to the cart, it will return with httpstatus of OK and message of item found
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "item found");
            // try block incase if code throws an exception
            try
            {
                //creates object  for onlineShopping Business layer class
                OnlineShoppingBusiness bll = new OnlineShoppingBusiness();
                //Retrives all the cart products and stores in the variable
                var cart = bll.GetCartProducts();
                //returns all the cart products
                errRes = Request.CreateResponse<List<CartProducts>>(cart);
            }
            //The exceptions will be handlesd here
            catch (Exception ex)
            {
                //If the items are not added to the cart, it will return  httpstatus of bad request and message of item not found
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "item not found");
            }
            //return the message
            return errRes;
        }
        /// <summary>
        /// This method will add the Cart items to the data base when clicked
        /// on the place order button and goes to order summary page
        /// </summary>
        /// <param name="lst"></param>

        [Route("api/OnlineShopping/PostToCart")]
        public HttpResponseMessage PostToCart([FromBody] CartProducts lst)
        {
            //If the items are added from the cart, it will return with httpstatus of OK and message of record inserted
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "Record inserted");
            // try block incase if code throws an exception
            try
            {
                //creates object  for onlineShopping Business layer class
                OnlineShoppingBusiness bll = new OnlineShoppingBusiness(); 
                //posts all the cart products to the database 
                bll.PostToCart(lst);
            }
            //The exceptions will be handlesd here
            catch (Exception ex)
            {
                //If the items are not added to the cart, it will return with httpstatus of BadRequest and message of item could not be added
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "item could not be added");
            }
            //returns message
            return errRes;
        }
        /// <summary>
        /// This method will delete the cart items in the displaycart page
        /// and returns to home page
        /// </summary>
        /// <param name="id"></param>
        [Route("api/OnlineShopping/DeleteFromCart/{id}")]
        public HttpResponseMessage DeleteFromCart(int id)
        {
            //If the item is deleted from the cart, it will return with httpstatus of OK and message of record deleted
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "Record deleted");
            // try block incase if code throws an exception
            try
            {
                //creates object  for onlineShopping Business layer class
                OnlineShoppingBusiness bll = new OnlineShoppingBusiness();
                //Deletes all the cart products by the user given ID
                bll.DeleteFromCartByID(id);
            }
            //The exceptions will be handlesd here
            catch (Exception ex)
            {
                //If the items is not added from the cart, it will return with httpstatus of BadRequest and message of item could not be deleted
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "item could not be deleted");
            }
            //returns the message
            return errRes;
        }
    }
}
