﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OnlineShoppingBusinessLayerLib;// for Online shopping business class
using OnlineShoppingEntitiesLib;// for Online shopping entity class
using OnlineShoppingExceptionLib;// for Online shopping data exception class



namespace OnlineShoppingSite.Controllers
{
    /// <summary>
    ///  This class extends the methods defined in business layer
    /// </summary>
    public class SecurityController : ApiController
    {
        /// <summary>
        ///  This method will give name of the user
        /// </summary>
        /// <param name="name"></param>
        /// <returns>returns the name of the user</returns>
        [Route("api/Security/GetUserName/{name}")]
        public HttpResponseMessage GetUserName(string name)
        {
                //If the items are added to the cart, it will return with httpstatus of OK and message of username found
                HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "username found");
                // try block incase if code throws an exception
                try
                {
                    //creates object  for onlineShopping Business layer class
                    OnlineShoppingBusiness bll = new OnlineShoppingBusiness();
                    //Retrives the username and stores in a variable
                    var log = bll.GetUserName(name);
                    //returns user name
                    errRes = Request.CreateResponse<Login>(log);
                }
                //The exceptions will be handlesd here
                catch (Exception ex)
                {
                    //If the items are not added to the cart, it will return  httpstatus of bad request and message of item not found
                    errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "item not found");
                }
                //return the message
                return errRes;
        }
        /// <summary>
        /// This method will give password of the user
        /// </summary>
        /// <param name="pwd"></param>
        /// <returns>returns the password of the user</returns>
        [Route("api/Security/GetPassword/{pwd}")]

        public HttpResponseMessage  GetPassword(string pwd)
        {
            //If the items are added to the cart, it will return with httpstatus of OK and message of Password found
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "password found");
            // try block incase if code throws an exception
            try
            {
                //creates object  for onlineShopping Business layer class
                OnlineShoppingBusiness bll = new OnlineShoppingBusiness();
                //Retrives the password and stores in a variable
                var logpw = bll.GetPassword(pwd);
                //returns password
                errRes = Request.CreateResponse<Login>(logpw);
            }
            //The exceptions will be handlesd here
            catch (Exception ex)
            {
                //If the items are not added to the cart, it will return  httpstatus of bad request and message of item not found
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, "item not found");
            }
            //return the message
            return errRes;
        }
    }
}
