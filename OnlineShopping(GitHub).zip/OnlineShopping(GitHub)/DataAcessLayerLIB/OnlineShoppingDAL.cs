﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using OnlineShoppingEntitiesLib;// for Online shopping entity class
using System.Configuration;
using OnlineShoppingExceptionLib;//for Online shopping Exception class

namespace OnlineShoppingDataAccessLayerLib
{
    /// <summary>
    /// This class extends the methods defined in data layer interaface
    /// </summary>
    public class OnlineShoppingDAL : IOnlineShoppingDAL
    {
        SqlConnection con;//sql connection
        SqlCommand cmd;//sql command
        /// <summary>
        /// Constructor for OnlineShoppingDataAccessLayerLib
        /// </summary>
        public OnlineShoppingDAL()
        {
            con = new SqlConnection();//configure connection object
            con.ConnectionString = ConfigurationManager.ConnectionStrings["sqlconstr"].ConnectionString;
        }


        /// <summary>
        /// This method will display the products present in category when clicked on category name
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products list present in the selected category</returns>
        public List<Product> GetProductsByProductName(string name)
        {
            //creates object of type list for Product entity class
            List<Product> lstprd = new List<Product>();
            // try block incase if code throws an exception
            try
            {
                //configure command for select statement
                cmd = new SqlCommand();
                //Query for selecting all the columns from Product table in database
                cmd.CommandText = "select ProductID,Image,ProductName,Price from Product where ProductName like @pn";
                //clearing out all of the parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding new value
                cmd.Parameters.AddWithValue("@pn", "%" + name + "%");
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the records from data reader 
                while (sdr.Read())
                {
                    Product prd = new Product
                    {
                        ProductID = (int)sdr[0],
                        Image = sdr[1].ToString(),
                        ProductName = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3])
                    };
                    //adds the details to list
                    lstprd.Add(prd);
                }
                //closing sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns list of Products 
            return lstprd;
        }


        /// <summary>
        /// This method will display the products present in category when clicked on category name
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products list present in the selected category</returns>
        public List<Product> GetProductsByCategoryName(string name)
        {
            //creates object of type list for Product entity class
            List<Product> lstprd = new List<Product>();
            // try block incase if code throws an exception
            try
            {
                //configure command for select statement
                cmd = new SqlCommand();
                  //Query for selecting all the columns from Product table according to given category name 
                cmd.CommandText = "select p.ProductID,p.Image,p.ProductName,p.Price from Product as p join" +
                    " tbl_Category as c on p.CategoryID=c.CategoryID and c.CategoryName like @cname";
                //clearing out all of the parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding new value
                cmd.Parameters.AddWithValue("@cname", name);
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the records from data reader
                while (sdr.Read())
                {
                    //creates object for Product
                    Product prd = new Product
                    {
                        ProductID = (int)sdr[0],
                        Image = sdr[1].ToString(),
                        ProductName = sdr[2].ToString(),
                        Price = Convert.ToDouble(sdr[3])
                    };
                    //adds the details to list
                    lstprd.Add(prd);
                }
                //closing sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns list of products related to category
            return lstprd;
        }


        /// <summary>
        /// This method will give full details of the product based on the product ID when clicked on the image
        /// </summary>
        /// <param name="id"></param>
        /// <returns>returns single product based on ID</returns>
        public Product GetProductById(int id)
        {
            //creates object for Product entity class
            Product pr = new Product();
            // try block incase if code throws an exception
            try
            {
                //configure command for select statement
                cmd = new SqlCommand();
                //Query for selecting product details from product table
                cmd.CommandText = "select * from Product where ProductID=@id";
                //clearing out all of the parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding new value
                cmd.Parameters.AddWithValue("@id", id);
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                //read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    pr.ProductID = (int)sdr[0];
                    pr.CategoryID = (int)sdr[1];
                    pr.ProductName = sdr[2].ToString();
                    pr.Image = sdr[3].ToString();
                    pr.Price = Convert.ToDouble(sdr[4]);
                    pr.AvailableOffers = sdr[5].ToString();
                    pr.Content = sdr[6].ToString();
                }
                //closing sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns product details
            return pr;
        }


        /// <summary>
        /// This method will give all the names of the category
        /// </summary>
        /// <returns>returns all the categories</returns>
        public List<Category> GetAllCategories()
        {
            //creates object of type list for Category entity class
            List<Category> lstprd = new List<Category>();
            // try block incase if code throws an exception
            try
            {
                //configure command for select statement
                cmd = new SqlCommand();
                //Query for selecting all the details from tbl_Category
                cmd.CommandText = "select * from tbl_Category";
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    //creates object for Category
                    Category c = new Category
                    {
                        CategoryID = (int)sdr[0],
                        CategoryName = sdr[1].ToString()
                    };
                    //adds details to list
                    lstprd.Add(c);
                }
                //closing sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns list of categories
            return lstprd;
        }


        /// <summary>
        /// This method will add the products to the cart when clicked on add to cart button 
        /// and returns to home page 
        /// </summary>
        /// <param name="lst"></param>
        public void AddToCart(List<CartProducts> lst)
        {
            int itemsEffected;
            // try block incase if code throws an exception
            try
            {
                //open the connection
                con.Open();
                foreach (var items in lst)
                {
                    //configure command for select statement
                    cmd = new SqlCommand();
                    //Query for inserting values into Tbl_orders
                    cmd.CommandText = "insert into Tbl_Orders(ProductID,ProductName,Price,Image,Quantity) values(@pid,@pname,@pr,@pic,@qa)";
                    //clearing out all of the parameters so that we can add new ones
                    cmd.Parameters.Clear();
                    //Adding new values
                    cmd.Parameters.AddWithValue("@pid", items.ProductID);
                    cmd.Parameters.AddWithValue("@pname", items.ProductName);
                    cmd.Parameters.AddWithValue("@pr", items.Price);
                    cmd.Parameters.AddWithValue("@pic", items.Image);
                    cmd.Parameters.AddWithValue("@qa", items.Quantity);
                    cmd.CommandType = System.Data.CommandType.Text;
                    //attach the connection with the command
                    cmd.Connection = con;
                    itemsEffected = cmd.ExecuteNonQuery();
                    if (itemsEffected == 0)
                    {
                        throw new Exception("items cannot be added to cart");
                    }
                }
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
        }


        /// <summary>
        /// This method will display all the cart items present in the data base
        /// </summary>
        /// <returns>returns the cart products </returns>
        public List<CartProducts> GetCartProducts()
        {
            //creates object of type list for cartProduct entity class
            List<CartProducts> lstCart = new List<CartProducts>();
            // try block incase if code throws an exception
            try
            {
                //configure command for select statement
                cmd = new SqlCommand();
                cmd.CommandText = "select * from Tbl_Orders";
                //clearing out all of the parameters so that we can add new ones
                cmd.Parameters.Clear();
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    //creates object for CartProducts
                    CartProducts cart = new CartProducts
                    {
                        ProductID = (int)sdr[0],
                        ProductName = sdr[1].ToString(),
                        Price = Convert.ToDouble(sdr[2]),
                        Image = sdr[3].ToString(),
                        Quantity = (int)sdr[4]
                    };
                    //adds the details to list
                    lstCart.Add(cart);
                }
                //closing sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns list of order products
            return lstCart;
        }


        /// <summary>
        /// This method will add the Cart items to the data base when clicked
        /// on the place order button and goes to order summary page
        /// </summary>
        /// <param name="lst"></param>
        public void PostToCart(CartProducts lst)
        {
            //configure command for select statement
            cmd = new SqlCommand();
            //attach the connection with the command
            cmd.Connection = con;
            //open the connection
            con.Open();
            // try block incase if code throws an exception
            try
            {
                //Query for selecting product details from product table
                cmd.CommandText = "insert into Tbl_Orders(ProductID,ProductName,Price,Image,Quantity) values(@pid,@pname,@pr,@pic,@qa)";
                //clearing out all of the parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding new values
                cmd.Parameters.AddWithValue("@pid", lst.ProductID);
                cmd.Parameters.AddWithValue("@pname", lst.ProductName);
                cmd.Parameters.AddWithValue("@pr", lst.Price);
                cmd.Parameters.AddWithValue("@pic", lst.Image);
                cmd.Parameters.AddWithValue("@pic", lst.Quantity);
                cmd.CommandType = System.Data.CommandType.Text;
                int itemsEffected = cmd.ExecuteNonQuery();
                if (itemsEffected == 0)
                {
                    throw new Exception("items cannot be added to cart");
                }
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
        }


        /// <summary>
        /// This method will delete the cart items in the displaycart page
        /// and returns to home page
        /// </summary>
        /// <param name="id"></param>
        public void DeleteFromCartByID(int id)
        {
            // try block incase if code throws an exception
            try
            {
                //configure command for select statement
                cmd = new SqlCommand();
                //Query for selecting product details from product table
                cmd.CommandText = "delete from Tbl_Orders where ProductID=@id";
                //clearing out all of the parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding new value
                cmd.Parameters.AddWithValue("@id", id);
                //specify the type of command
                cmd.CommandType = System.Data.CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                int recordsAffected = cmd.ExecuteNonQuery();
                con.Close();
                if (recordsAffected == 0)
                {
                    throw new Exception("Item does not exist in cart");
                }
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
        }


        /// <summary>
        /// This method will give user name from tbl_UserDetail
        /// </summary>
        /// <param name="name"></param>
        /// <returns>returns username</returns>
        public Login GetUserName(string name)
        {
            //creates object of type log for Login class
            Login log = new Login();
            // try block incase if code throws an exception
            try
            {
                //configure command for select statement
                cmd = new SqlCommand();
                //Query for selecting product details from product table
                cmd.CommandText = "select UserName from tbl_UserDetail where UserName=@un";
                //clearing out all of the parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding new value
                cmd.Parameters.AddWithValue("@un", name);
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                { 
                    log.UserName = sdr[0].ToString();
                }
                //closing sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
            //return username
            return log;
        }


        /// <summary>
        ///This method will give password from tbl_UserDetail
        /// </summary>
        /// <param name="pwd"></param>
        /// <returns>returns password</returns>
        public Login GetPassword(string pwd)
        {
            //creates object of type log for Login entity class
            Login log = new Login();
            try
            {
                cmd = new SqlCommand();
                //Query for selecting product details from product table
                cmd.CommandText = "select password from tbl_UserDetail where password=@pwd";
                //clearing out all of the parameters so that we can add new ones
                cmd.Parameters.Clear();
                //Adding new value
                cmd.Parameters.AddWithValue("@pwd", pwd);
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach the connection with the command
                cmd.Connection = con;
                //open the connection
                con.Open();
                //executes the command
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    log.Password = sdr[0].ToString();
                }
                //closing sdr connection
                sdr.Close();
            }
            //If sqlexception occurs, it will handle here
            catch (SqlException ex)
            {
                throw new OnlineException("Some database error occurred :" + ex.Message);
            }
            //other than sql exceptions will be handlesd here
            catch (Exception ex)
            {
                throw new OnlineException("some database error occured :" + ex.Message);
            }
            //The finally block will execute when the try/catch block leaves the execution, it always executes
            finally
            {
                //closing the connection
                con.Close();
            }
            //returns password
            return log;
        }
    }
}
                             