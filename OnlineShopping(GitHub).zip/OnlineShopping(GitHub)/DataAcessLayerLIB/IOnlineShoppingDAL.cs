﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShoppingEntitiesLib;// for Online shopping entity class

namespace OnlineShoppingDataAccessLayerLib
{
    /// <summary>
    /// Interface for Online shopping data layer
    /// </summary>
    public interface IOnlineShoppingDAL
    {
        /// <summary>
        /// This method will display the products present in category when clicked on category name
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products list present in the selected category</returns>
        List<Product> GetProductsByCategoryName(string name);
        /// <summary>
        /// This method will display the products based on the name given by user 
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products with the searched product</returns>
        List<Product> GetProductsByProductName(string name);
        /// <summary>
        /// This method will give full details of the product based on the product ID when clicked on the image
        /// </summary>
        /// <param name="id"></param>
        /// <returns>returns single product based on ID</returns>
        Product GetProductById(int id);
        /// <summary>
        /// This method will give all the names of the category
        /// </summary>
        /// <returns>returns all the categories</returns>
        List<Category> GetAllCategories();
        /// <summary>
        /// This method will add the products to the cart when clicked on add to cart button 
        /// and returns to home page 
        /// </summary>
        /// <param name="lst"></param>
        void AddToCart(List<CartProducts> lst);
        /// <summary>
        /// This method will display all the cart items present in the data base
        /// </summary>
        /// <returns>returns the cart products </returns>
        List<CartProducts> GetCartProducts();
        /// <summary>
        /// This method will add the Cart items to the data base when clicked
        /// on the place order button and goes to order summary page
        /// </summary>
        /// <param name="lst"></param>
        void PostToCart(CartProducts lst);
        /// <summary>
        /// This method will delete the cart items in the displaycart page
        /// and returns to home page
        /// </summary>
        /// <param name="id"></param>
        void DeleteFromCartByID(int id);
        /// <summary>
        /// This method will give user name from tbl_UserDetail
        /// </summary>
        /// <param name="name"></param>
        /// <returns>returns username</returns>
        Login GetUserName(string name);
        /// <summary>
        ///This method will give password from tbl_UserDetail
        /// </summary>
        /// <param name="pwd"></param>
        /// <returns>returns password</returns>
        Login GetPassword(string pwd);
    }
}
