﻿--insering values into tbl_Category
insert into tbl_Category values(1,'Electronics')

insert into tbl_Category values(2,'Clothing')

insert into tbl_Category values(3,'Furniture')

insert into tbl_Category values(4,'sports')

insert into tbl_Category values(5,'Books')

--Retreiving data from the table
select * from tbl_Category

--inserting values into table product
insert into Product values(1,1,'Redmic15','realme15.jpg',9999,'Bank offer 10% off on ICCI and Axis Credit cards','BrandName:Redmi,Specifications:4GB RAM 64GB ROM Expandable upto 512GB |6000mAh lithium-ion battery|16.56cm(6.52 inch) HD+Display')

insert into Product values(2,1,'RedmiNote8','redmi8.jpg',11499.00,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName:RedMi,Specifications:4GB RAM 64GB ROM Expandable upto 512GB|4000mAh lithium-polymer battery|16.0 cm (6.3 inch) Full HD+ Display')

insert into Product values(3,1,'OPPOA83','oppo.jpg',7490,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName:OPPO,Specifications:4GB RAM 64GB ROM Expandable upto 512GB|3180mAh battery|14.48 cm (5.7 inch) Display')

insert into Product values(4,1,'Apple iPhone 8 Plus','apple.jpg',49900,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName: Apple,specifications: 64GB ROM|13.97 cm (5.5 inch)Retina HD Display')

insert into Product values(5,1,'Mi 4A PRO','mi.jpg',14999,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName:MI,specifications:Operating System: Android (Google Assistant & Chromecast in-built),Resolution: HD Ready 1366 x 768 Pixels')

insert into Product values(6,1,' JANVI014 Smart Headphones ','janvi.jpg',399,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName: Janvi,specifications: WirelessTimeTracking,Color: Black|Supports Bluetooth')

insert into Product values(7,1,'LG80','lg.jpg',15999,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName:MI,specifications:Operating System: Android (Google Assistant & Chromecast in-built),Resolution: HD Ready 1366 x 768 Pixels')

insert into Product values(8,2,'Color Block Women Round Neck Yellow T-Shirt','tshirt.jpg',350,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName: Subzero fashion,Size: M|L|XL,Colour: black')

insert into Product values(9,2,'Women A-line Black Dress','dress.jpg',749,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName:NOVUS CREATIONS ,Size:M,L,XL,Colour:black')

insert into Product values(10,2,'Solid Men Polo Neck Green T-Shirts','dress2.jpg',699,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName:Louis Philippe Sport,Size: M|L|XL,Colour:grey')

insert into Product values(11,2,'Solid Men Mandarin Collar Green T-Shirt','dress3.jpg',299,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName: Seven Rocks,Size: M|L|XL,Colour: green')

insert into Product values(12,3,'SAF BUDDHA SPARKLE','paintin.jpg',399,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','Theme: Religious | Water Resistant')

insert into Product values(13,3,'SAF Digital Reprint ','painting.jpg',199,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','Theme: Religious | Water Resistant')

insert into Product values(14,4,'Stump Set','set.jpg',199,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName:REDWAY SPORTS | Made of PVC | Plastic,Color: Green | Black')

insert into Product values(15,4,'Cricket Bat Handle Gripper','set2.jpg',299,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName:Kiraro Set | Made of PVC | Plastic,Color:Black')

insert into Product values(16,5,'Indian Banking ','book.jpg',151,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','BrandName: SChand Publications,Description: For the students of B.Com of different Indian Universities and also useful for Banking Sector employees')

insert into Product values(17,5,'Baaz','baaz.jpg',267,'Bank offer 10% off on ICCI aninsert into prd Axis Credit cards','Language: English,Binding: Paperback,Publisher: HarperCollins Publishers India,Genre: Fiction')

--Retreiving data from the table
select * from Product

--inserting values into tbl_UserDetails
insert into tbl_UserDetail values('Keerthana','abcd')

--Retreiving data from the table
select * from tbl_UserDetail

--Retreiving data from the table
select * from Tbl_Orders


