﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingExceptionLib
{
    /// <summary>
    /// OnlineShopping Exception class
    /// </summary>
    public class OnlineException:Exception
    {
        /// <summary>
        /// TODO log the error in file or elsewhere
        /// </summary>
        /// <param name="errMsg"></param>
        public OnlineException(string errMsg) : base(errMsg)
        {

        }
    }
}
