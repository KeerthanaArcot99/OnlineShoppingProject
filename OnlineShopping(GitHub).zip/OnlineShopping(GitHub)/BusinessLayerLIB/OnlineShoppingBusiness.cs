﻿using OnlineShoppingEntitiesLib;// for Online shopping entity class
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OnlineShoppingDataAccessLayerLib;// for Online shopping data acesss layer
using OnlineShoppingExceptionLib;// for Online shopping data exception class

namespace OnlineShoppingBusinessLayerLib
{
    /// <summary>
    ///  This class extends the methods defined in Business layer interaface
    /// </summary>
    public class OnlineShoppingBusiness : IOnlineShoppingBusiness
    {
        /// <summary>
        /// This method will add the products to the cart when clicked on add to cart button 
        /// and returns to home page 
        /// </summary>
        /// <param name="lst"></param>
        public void AddToCart(List<CartProducts> lst)
        {
            // try block incase if code throws an exception
            try
            {
                //creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                //adds all the cart products
                dal.AddToCart(lst);
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }
        /// <summary>
        /// This method will delete the cart items in the displaycart page
        /// and returns to home page
        /// </summary>
        /// <param name="id"></param>
        public void DeleteFromCartByID(int id)
        {
            // try block incase if code throws an exception
            try
            {
                ///creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                //Deletes all the cart products by the user given ID
                dal.DeleteFromCartByID(id);
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }

        /// <summary>
        /// This method will give all the names of the category
        /// </summary>
        /// <returns>returns all the categories</returns>
        public List<Category> GetAllCategories()
        {
            // try block incase if code throws an exception
            try
            {
                ///creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                //Retrives all the categories from the database and stores in the variable
                var lstprd = dal.GetAllCategories();
                //returns list of categories 
                return lstprd;
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }
        /// <summary>
        /// This method will display all the cart items present in the data base
        /// </summary>
        /// <returns>returns the cart products </returns>
        public List<CartProducts> GetCartProducts()
        {
            // try block incase if code throws an exception
            try
            {
                ///creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                //Retrives all the cart products and stores in the variable
                var lstCart = dal.GetCartProducts();
                //returns list of  cart Products 
                return lstCart;
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }

        /// <summary>
        ///This method will give password from tbl_UserDetail
        /// </summary>
        /// <param name="pwd"></param>
        /// <returns>returns password</returns>
        public Login GetPassword(string pwd)
        {
            // try block incase if code throws an exception
            try
            {
                ///creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                var log = dal.GetPassword(pwd);
                //returns list of  cart Products 
                return log;
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }

        /// <summary>
        /// This method will give full details of the product based on the product ID when clicked on the image
        /// </summary>
        /// <param name="id"></param>
        /// <returns>returns single product based on ID</returns>
        public Product GetProductById(int id)
        {
            // try block incase if code throws an exception
            try
            {
                ///creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                //Retrives all the product details by ID and stores in the variable
                var prd = dal.GetProductById(id);
                //returns details of Product 
                return prd;
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }
        /// <summary>
        /// This method will display the products present in category when clicked on category name
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products list present in the selected category</returns>
        public List<Product> GetProductsByCategoryName(string name)
        {
            // try block incase if code throws an exception
            try
            {
                ///creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                //Retrives all the products according to category name and stores in the variable
                var lstprd = dal.GetProductsByCategoryName(name);
                //returns list of Products 
                return lstprd;
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }
        /// <summary>
        /// This method will display the products based on the name given by user 
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products with the searched product</returns>
        public List<Product> GetProductsByProductName(string name)
        {
            // try block incase if code throws an exception
            try
            {
                ///creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                //Retrives all the Products from the database and stores in the variable
                var lstcat = dal.GetProductsByProductName(name);
                //returns list of Products 
                return lstcat;
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }
        /// <summary>
        /// This method will give user name from tbl_UserDetail
        /// </summary>
        /// <param name="name"></param>
        /// <returns>returns username</returns>
        public Login GetUserName(string name)
        {
            // try block incase if code throws an exception
            try
            {
                ///creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                var log = dal.GetUserName(name);
                //returns list of  cart Products 
                return log;
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }

        /// <summary>
        /// This method will add the Cart items to the data base when clicked
        /// on the place order button and goes to order summary page
        /// </summary>
        /// <param name="lst"></param>
        public void PostToCart(CartProducts lst)
        {
            // try block incase if code throws an exception
            try
            {
                ///creates object  for onlineShopping data access layer class
                OnlineShoppingDAL dal = new OnlineShoppingDAL();
                //posts all the cart products to the database 
                dal.PostToCart(lst);
            }
            //The exceptions will be handlesd here
            catch (OnlineException ex)
            {
                //throws exception
                throw ex;
            }
        }
    }
}
