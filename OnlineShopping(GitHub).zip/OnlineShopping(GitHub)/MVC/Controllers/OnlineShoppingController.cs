﻿using Newtonsoft.Json;
using OnlineShoppingMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace OnlineShoppingMVC.Controllers
{
    public class OnlineShoppingController : Controller
    {
          // GET: OnlineShopping
        /// <summary>
        /// This will give the home page with list of categories 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:64278/api/");
            //call API 
            using (var client = new HttpClient())
            {
                //sets the base address defines the uri path
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OnlineShopping").Result;
                //gets the list of categories 
                var lstprd = JsonConvert.DeserializeObject<List<Category>>(result);
                //returns lst of categories
                return View(lstprd);
            }
        }
        /// <summary>
        /// This method will display the products based on the name given by user 
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products with the searched product</returns>
        [HttpGet]
        [Route("api/OnlineShopping/GetProductsByProductName/{name}")]
        public ActionResult GetProductsByProductName(string name)
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:64278/api/OnlineShopping/");
            //call API 
            using (var client = new HttpClient())
            {
                //sets the base address defines the url
                client.BaseAddress = uri;
                //Sends a Get Request to the Specified Uri
                var result = client.GetStringAsync("GetProductsByProductName/" + name).Result;
                //gets the list of products by the product name
                var lstprd = JsonConvert.DeserializeObject<List<Product>>(result);
                //returns lst of products
                return View(lstprd);
            }

        }
        /// <summary>
        /// This method will display the products present in category when clicked on category name
        /// </summary>
        /// <param name="name"></param>
        /// <returns>It returns the products list present in the selected category</returns>
        [HttpGet]
        [Route("api/OnlineShopping/GetProductsByCategoryName/{name}")]
        public ActionResult GetProductsByCategoryName(string name)
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:64278/api/OnlineShopping/");
            //call API 
            using (var client = new HttpClient())
            {
                //sets the base address defines the url
                client.BaseAddress = uri;
                //Sends a Get Request to the Specified Uri
                var result = client.GetStringAsync("GetProductsByCategoryName/" + name).Result;
                //gets the list of products by category name
                var lstprd = JsonConvert.DeserializeObject<List<Product>>(result);
                //return list of products
                return View(lstprd);
            }

        }
        /// <summary>
        /// This method will give full details of the product based on the product ID when clicked on the image
        /// </summary>
        /// <param name="id"></param>
        /// <returns>returns single product based on ID</returns>

        [HttpGet]
        [Route("api/OnlineShopping/GetProductById/{id}")]
        public ActionResult GetProductById(int id)
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:64278/api/OnlineShopping/");
            //call API 
            using (var client = new HttpClient())
            {
                //sets the base address defines the url
                client.BaseAddress = uri;
                //Sends a Get Request to the Specified Uri
                var result = client.GetStringAsync("GetProductById/" + id).Result;
                //gets the list of product details by product ID
                var lstrec = JsonConvert.DeserializeObject<Product>(result);
                //returns list of product details
                return View(lstrec);
            }
        }
        /// <summary>
        /// This will add the cart items in the session
        /// </summary>
        /// <returns>returns to index page</returns>
        [HttpGet]
        public ActionResult AddToCart()
        {
            return View();
        }
        /// <summary>
        /// This method will add the products to the cart when clicked on add to cart button 
        /// and returns to home page 
        /// </summary>
        /// <param name="item"></param>
        /// <returns>returns to home page </returns>
        [HttpPost]
        public ActionResult AddToCart(CartProduct item)
        {
            //Making the quantity as 1
            item.Quantity = 1;
            //checking the condition by assuming cart as empty
            if(Session["cart"]==null)
            {
                //creating instance of list of cart items
                List<CartProduct> items = new List<CartProduct>();
                //add cart items to cart list
                items.Add(item);
                //add the items in cart to session
                Session.Add("cart", items);
            }
            //if session cart is not empty
            else
            {
                //get the cart from the session
                var cartLst = (List<CartProduct>)Session["cart"];
                //adds next cart products to cart list
                cartLst.Add(item);
                //update cart in session
                Session["cart"] = cartLst;
            }
            //returns the index page after adding cart product to cart
            return RedirectToAction("Index",new { id = item.ProductID }); 
        }
        /// <summary>
        /// This will displays the list of cart items 
        /// </summary>
        /// <returns>list of cart products</returns>
        public ActionResult DisplayCart()
        {
            //get the cart from the session
            var lst = (List<CartProduct>)Session["Cart"];
            //add the iitems in cart to session
            Session.Add("cart1", lst);
            //returns the list of cart items
            return View(lst);
        }
        /// <summary>
        /// This method will add the Cart items to the data base when clicked
        /// on the place order button and goes to order summary page
        /// </summary>
        /// <returns>returns the cart items</returns>
        public ActionResult PostCart()
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:64278/api/");
            //get the cart from the session
            var cartList = (List<CartProduct>)Session["cart"];
            //call API 
            using (var client = new HttpClient())
            {
                //sets the base address defines the url
                client.BaseAddress = uri;
                //Sends a post Request to the Specified Uri
                var result = client.PostAsJsonAsync<List<CartProduct>>("OnlineShopping/AddToCart/", cartList).Result;
                //If the items are added from the cart, it will return with successtatus of true and message of posted
                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg", "Posted");
                }
                //If the items are not added from the cart, it will return with successtatus of false and message of error             
                else
                {
                    ViewData.Add("msg", "error");
                }
            }
            //returns list of cart items
            return View(cartList);
        }
        /// <summary>
        /// iThis will insert cartlist into database and remove from session
        /// </summary>
        [Authorize]
        [HttpGet]
        public ActionResult PlaceOrder()
        {
            var cart = (List<CartProduct>)Session["cart"];
            //insert cartlist into database and remove from session
            cart.Clear();
            //update the cart in the session
            Session["cart"] = cart;
            //it returns to the "PlaceOrder" view
            return View();
        }
        /// <summary>
        /// This will delete the cart products in the session
        /// </summary>
        /// <param name="id"></param>
        /// <returns>returns to the index page</returns>
        [HttpGet]
        public ActionResult DeleteFromCart(int id)
        {
            var cartList = (List<CartProduct>)Session["cart"];
            //deletes the item 
            var item = cartList.Where(o => o.ProductID == id).FirstOrDefault();
            //removes the items in the cart
            cartList.Remove(item);
            Session["cart"] = cartList;
            //returns to index page
            return RedirectToAction("Index");
        }
        /// <summary>
        /// This will update the cart products like quantity
        /// </summary>
        /// <param name="id"></param>
        [HttpGet]
        public ActionResult UpdateCartByProductID(int id)
        {
            var cartItemsList = (List<CartProduct>)Session["cart"];
            var cartItem = cartItemsList.Where(o => o.ProductID == id).FirstOrDefault();
            return View(cartItem);
        }
        /// <summary>
        /// This will save the Updated cart products
        /// </summary>
        /// <param name="cartItems"></param>
        /// <returns>returns to the display cart</returns>
        [HttpPost]
        public ActionResult UpdateCartByProductID(CartProduct cartItems)
        {
            //gets the cart from the session and stores in variable
            var cartItemsList = (List<CartProduct>)Session["cart"];
            var cartItem = cartItemsList.Where(o=> o.ProductID == cartItems.ProductID).FirstOrDefault();
            cartItem.Quantity =cartItems.Quantity;
            //update the cart in the session
            Session["cart"] = cartItemsList;
            //returns to Displaycart
            return RedirectToAction("DisplayCart");
        }
        /// <summary>
        /// This will delete the cart products in data base
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/OnlineShopping/DeleteFromCart/{id}")]
        public ActionResult DeleteOrderByID(int id)
        {
            //localhost connection of API
            Uri uri = new Uri("http://localhost:64278/api/");
            //call API 
            using (var client = new HttpClient())
            {
                //sets the base address defines the url
                client.BaseAddress = uri;
                //Sends a Delete Request to the Specified Uri
                var result = client.DeleteAsync("OnlineShopping/DeleteFromCart/" + id).Result;
            }
            //Returns to Index
            return RedirectToAction("Index");
        }

    }
}