﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using OnlineShoppingMVC.Models;
using Newtonsoft.Json;
using System.Web.Security;

namespace OnlineShoppingMVC.Controllers
{
    public class SecurityController : Controller
    {
        // GET: Security
        /// <summary>
        /// This will give the login page
        /// </summary>
        /// <returns></returns>
       [HttpGet]
       public ActionResult Login()
        {
            //
            var returnUrl = Request.QueryString.Get("ReturnUrl");
            ViewData.Add("returnUrl", returnUrl);
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login obj)
        {
            //localhost for api
            Uri uri = new Uri("http://localhost:64278/api/");
            //call Api
            using (var client = new HttpClient())
            {
                //Sets the base address that defines the uri
                client.BaseAddress = uri;
                //Sends a get request to uri
                var res = client.GetStringAsync("Security/GetUserName/" + obj.UserName).Result;
                //gets the username entered by the user
                var name = JsonConvert.DeserializeObject<Login>(res);
                //storing in the user
                string user = name.UserName;
                //Sends a get request to uri
                var result = client.GetStringAsync("Security/GetPassword/" + obj.Password).Result;
                //gets the password entered by the user
                var password = JsonConvert.DeserializeObject<Login>(result);
                //storing in the passWord
                string passWord = password.Password;
                //checks the username and password
                if((obj.UserName.Equals(user)) && (obj.Password.Equals(passWord)))
                {
                    FormsAuthentication.SetAuthCookie(obj.UserName, false);
                    var returnUrl = Request.Form["returnUrl"];
                    return Redirect(returnUrl);
                }
                //when details don't match then it will print error msg
                else
                {
                    ModelState.AddModelError("UserName", "Username and password are invalid, please try again.");
                }
                var returnUrl1 = Request.QueryString.Get("ReturnUrl");
                ViewData.Add("returnUrl", returnUrl1);
                return View();
            }
        }
       [HttpPost]
       public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return View();
        }
    }
}