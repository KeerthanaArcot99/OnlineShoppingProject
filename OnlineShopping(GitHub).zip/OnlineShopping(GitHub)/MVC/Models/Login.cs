﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineShoppingMVC.Models
{
    /// <summary>
    /// Login Class
    /// </summary>
    public class Login
    {
        /// <summary>
        /// Username(name of the user)
        /// </summary>
      [Required(ErrorMessage ="User name should be given")]
      [StringLength(15, MinimumLength =5, ErrorMessage ="user name must be between 5 and 15 characters")]
        public string UserName { get; set; }
        /// <summary>
        /// password
        /// </summary>
       [Required(ErrorMessage ="Password field must be filled")]
       [StringLength(8, MinimumLength = 3, ErrorMessage = "password must be between 3 and 8 characters")]
        public string Password { get; set; }
    }
}