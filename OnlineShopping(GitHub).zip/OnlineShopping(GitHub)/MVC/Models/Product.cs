﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShoppingMVC.Models
{
    /// <summary>
    /// Product Class
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Product ID
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// Category ID
        /// </summary>
        public int CategoryID { get; set; }
        /// <summary>
        /// Product Name(Name of product)
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// Image(Image of the product)
        /// </summary>
        public string Image { get; set; }
        /// <summary>
        /// Price(Price of the product)
        /// </summary>
        public double Price { get; set; }
        /// <summary>
        /// Available Offers(Offers available for purchasing)
        /// </summary>
        public string AvailableOffers { get; set; }
        /// <summary>
        /// Content(Other Description about product)
        /// </summary>
        public string Content { get; set; }
        /// <summary>
        /// Function to make the content split by colon and commas
        /// </summary>
        /// <returns></returns>
        public string DisplayContent()
        {
            string data = "";
            string[] cols = Content.Split(',');
            foreach (var col in cols)
            {
                string colName, colValue;
                string[] colValues = col.Split(':');
                colName = colValues[0];
                colValue = colValues[1];
                data +="<b>"+ colName +"</b>"+ ":" + colValue + "<br/><br/>";
            }
            return data;
        }
    }
}