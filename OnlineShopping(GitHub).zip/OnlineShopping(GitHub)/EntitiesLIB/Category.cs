﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingEntitiesLib
{
    /// <summary>
    /// Category class
    /// </summary>
    public class Category
    {
        /// <summary>
        /// Category ID
        /// </summary>
        public int CategoryID { get; set; }
        /// <summary>
        /// Category Name(Name of category)
        /// </summary>
        public string CategoryName { get; set; }

    }
}
