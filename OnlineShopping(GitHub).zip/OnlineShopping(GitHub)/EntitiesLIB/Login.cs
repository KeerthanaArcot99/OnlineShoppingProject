﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingEntitiesLib
{
    /// <summary>
    /// Login Class
    /// </summary>
    public class Login
    {
        /// <summary>
        /// UserName(name of the user)
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// password
        /// </summary>
        public string Password { get; set; }
    }
}
