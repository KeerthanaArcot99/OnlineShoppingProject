﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingEntitiesLib
{
    /// <summary>
    /// Cart Products class
    /// </summary>
    public class CartProducts
    {
        /// <summary>
        /// Product ID
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// Product Name(Name of the product)
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// Price(Price of the product)
        /// </summary>
        public double Price { get; set; }
        /// <summary>
        /// Image(Image of the product)
        /// </summary>
        public string Image { get; set; }
        /// <summary>
        /// Quantity(Quantity of the product)
        /// </summary>
        public int Quantity { get; set; }
    }
}
