﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnlineShoppingEntitiesLib
{
    /// <summary>
    /// Product Class
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Product ID
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// Category ID
        /// </summary>
        public int CategoryID { get; set; }
        /// <summary>
        /// Product Name(Name of product)
        /// </summary>
        public string ProductName { get; set; }
        /// <summary>
        /// Image(Image of the product)
        /// </summary>
        public string Image { get; set; }
        /// <summary>
        /// Price(Price of the product)
        /// </summary>
        public double Price { get; set; }
        /// <summary>
        /// Available Offers(Offers available for purchasing)
        /// </summary>
        public string AvailableOffers { get; set; }
        /// <summary>
        /// Content(Other Description about product)
        /// </summary>
        public string Content { get; set; }
      
    }
}
